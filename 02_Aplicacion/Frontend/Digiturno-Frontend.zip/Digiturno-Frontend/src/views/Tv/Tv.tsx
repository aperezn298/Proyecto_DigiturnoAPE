import { HeaderTv } from "../../components/Header"
import {TablaTV } from "./index"
export const Tv  =()=>{
    return <> 
    <HeaderTv/>
    <TablaTV/>
    </>
}