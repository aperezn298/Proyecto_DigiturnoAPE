export const tipoIdentidad = [
    { value: "CC", nombre: "Cédula de Ciudadanía" },
    { value: "RC", nombre: "Registro Civil" },
    {value:"TE" , nombre: "Targeta de Identidad "}
    
  ];
  
 export  const tipoUsuarioId = [
    { id: 1, nombre: "Natural" },
    { id: 2, nombre: "Empresa" },
  ];
 export  const tipoPoblacionId = [
   {id: 18,nombre: "Ninguna"},
    {id: 1, nombre: "Población Víctimas de la violencia"},
    {id: 2,nombre: "Población con discapacidad"},
    {id: 3,nombre: "Población Indígena"},
    {id: 4,nombre: "Población afrocolombiana"},
    {id: 5,nombre: "Población Comunidades Negras"},
    {id: 6,nombre: "Población Palenquera"},
    {id: 7,nombre: "Población Raizales"},
    {id: 8, nombre: "Población Privada de la Libertad"},
    {id: 9, nombre: "Población Víctimas de trata de personas"},
    {id: 10,nombre: "Tercera Edad"},
    {id: 11,nombre: "Población Adolescentes y Jóvenes Vulnerables"},
    {id: 12,nombre: "Población  en Conflicto con ley penal"},
    {id: 13,nombre: "Población Mujer Cabeza de Hogar"},
    {id: 14, nombre: "Población en Proceso de Reincorporación"},
    {id: 15,nombre: "Población en Proceso de Reintegración"},
    {id: 16, nombre: "Pueblo Rom"},
    {id: 17,nombre: "Población Víctimas Ataque con Agente Químicos"},

  ];

  