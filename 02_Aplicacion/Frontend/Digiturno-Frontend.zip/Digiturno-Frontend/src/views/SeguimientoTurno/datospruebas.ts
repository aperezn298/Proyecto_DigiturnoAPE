export const DatosTurnos = [
  {
    "id": 65,
    "codigo": "AAO001",
    "fecha": "2024-12-22",
    "estado": "Espera",
    "horaAsignacion": "11:34:54",
    "usuario": {
      "id": 75,
      "nombres": "Thiago",
      "apellidos": "Cumban Chero"
    },
    "empleado": {
      "id": 23,
      "modulo": {
        "modulo": 7
      }
    },
    "servicios": [
      {
        "icono": "https://res.cloudinary.com/doza0twgj/image/upload/v1734112071/uploads/ryyb5vxc9xgngn82g4xq.png",
        "servicioTurno": {
          "id": 121,
          "servicioId": 2,
          "turnoId": 65
        }
      }
    ]
  },{
    "id": 65,
    "codigo": "AAO001",
    "fecha": "2024-12-22",
    "estado": "Espera",
    "horaAsignacion": "11:34:54",
    "usuario": {
      "id": 75,
      "nombres": "Thiago",
      "apellidos": "Cumban Chero"
    },
    "empleado": {
      "id": 23,
      "modulo": {
        "modulo": 7
      }
    },
    "servicios": [
      {
        "icono": "https://res.cloudinary.com/doza0twgj/image/upload/v1734112071/uploads/ryyb5vxc9xgngn82g4xq.png",
        "servicioTurno": {
          "id": 121,
          "servicioId": 2,
          "turnoId": 65
        }
      }
    ]
  },{
    "id": 65,
    "codigo": "AAO001",
    "fecha": "2024-12-22",
    "estado": "Espera",
    "horaAsignacion": "11:34:54",
    "usuario": {
      "id": 75,
      "nombres": "Thiago",
      "apellidos": "Cumban Chero"
    },
    "empleado": {
      "id": 23,
      "modulo": {
        "modulo": 7
      }
    },
    "servicios": [
      {
        "icono": "https://res.cloudinary.com/doza0twgj/image/upload/v1734112071/uploads/ryyb5vxc9xgngn82g4xq.png",
        "servicioTurno": {
          "id": 121,
          "servicioId": 2,
          "turnoId": 65
        }
      }
    ]
  },
  ] 