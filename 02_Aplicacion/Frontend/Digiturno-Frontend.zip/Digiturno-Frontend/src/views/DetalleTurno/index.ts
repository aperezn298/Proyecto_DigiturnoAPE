export * from "./Detalleturno"
export * from "./informacion"
